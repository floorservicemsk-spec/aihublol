import { base44 } from './base44Client';


export const ChatSession = base44.entities.ChatSession;

export const KnowledgeBase = base44.entities.KnowledgeBase;

export const AISettings = base44.entities.AISettings;

export const FAQCategory = base44.entities.FAQCategory;

export const FAQ = base44.entities.FAQ;

export const Video = base44.entities.Video;

export const VideoCategory = base44.entities.VideoCategory;

export const Order = base44.entities.Order;

export const LegalEntity = base44.entities.LegalEntity;

export const QuoteShareLog = base44.entities.QuoteShareLog;

export const IntegrationConfig = base44.entities.IntegrationConfig;

export const AdviceCategory = base44.entities.AdviceCategory;

export const AdviceTag = base44.entities.AdviceTag;

export const AdviceMedia = base44.entities.AdviceMedia;

export const AdviceArticle = base44.entities.AdviceArticle;

export const AdviceFavorite = base44.entities.AdviceFavorite;

export const HomeBanner = base44.entities.HomeBanner;

export const DealerProfile = base44.entities.DealerProfile;

export const DealerTierChangeLog = base44.entities.DealerTierChangeLog;

export const BonusSettings = base44.entities.BonusSettings;



// auth sdk:
export const User = base44.auth;